package JSON;

//Imports
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JSONSourceCode {
	public static void main(String[] args) {
	JSONParser parser = new JSONParser();
	  try {		  
		  //read .json file using parser
		  Object object = parser.parse(new FileReader("C:\\RyanBennettCodingExcercise\\UTIMCO Coding Exercise\\doc\\JSONSourceCodeCleanup.json"));
		  JSONArray JSONInputFile = (JSONArray) object;
		  for (Object o : JSONInputFile){
			int count = 0;
		    //open menu
			JSONObject menu = (JSONObject) o;
		    //get menu
			JSONObject header = (JSONObject) menu.get("menu");
		    //get items
			JSONArray items = (JSONArray) header.get("items");
		    //for loop to find ids that have labels
				for(int i = 0 ; i < items.size(); i++){    	
			    	JSONObject tempJSONObject = (JSONObject) items.get(i);
			    	//get id number from ids that have labels
			    	if(tempJSONObject.get("label") != null){
			    		String parseStringGetInteger = tempJSONObject.get("id").toString();
			    		int JSONIdNumber = Integer.parseInt(parseStringGetInteger);
			    		//count numbers
			    		count += JSONIdNumber;
			    	}    
				}
		    //print added id numbers
			System.out.println(count);
		  }
	  //catch statements
	  } catch (FileNotFoundException e) {
          e.printStackTrace();
      } catch (IOException e) {
          e.printStackTrace();
      } catch (org.json.simple.parser.ParseException e) {
          e.printStackTrace();
      }
	}
}